<?php

function stairsteps($stairs)
{
    for ($row = $stairs - 1; $row >= 0; $row--) {
        $spaces = "";
        $end = "&nbsp&nbsp&nbsp&nbsp";
        // Spaces
        for ($space = 0; $space < $row; $space++) {
            $spaces .= "&nbsp&nbsp&nbsp&nbsp";
        }
        // end Spaces
        for ($count = 1; $count < $stairs - $row; $count++) {
            $end .= '&nbsp&nbsp&nbsp&nbsp';
        }
        //printing head
        if ($stairs - $row == 1) {
            echo "$spaces  o *****";
        } else {
            echo "$spaces" . " o  *****" . substr($end, 4) . "*<";
        }
        echo "<br>";
        //printing body
        echo "" . $spaces . " /|\  *" . $end . "*";
        echo "<br>";
        echo "" . $spaces . " / \  *" . $end . "*";
        echo "<br>";
        //printing end line
        $lastLine = '';
        for ($count = 0; $count <= $stairs; $count++) {
            $lastLine .= '****';
        }
        echo "$lastLine";
        echo "<br>";
    }
}

    stairsteps(5);
    phpinfo();