<?php

echo "Thank you for your request. We'll be in touch soon!<br><br>";

echo "<a href='home.html'>Return to the home page</a>";