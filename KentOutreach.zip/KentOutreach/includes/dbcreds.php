<?php

//Connect to database
$database = 'javachip_grc';
$username = 'javachip_javachip';
$password = 'WootWoot1!';
$hostname = 'localhost';


$cnxn = @mysqli_connect($hostname, $username, $password, $database)
or die("There was a problem.");
//var_dump($cnxn);

