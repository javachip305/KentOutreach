$(document).ready(function() {
    $('#requests-table').DataTable( {
        order: [[ 6, 'desc' ], [ 1, 'asc' ]]
    } );
} );