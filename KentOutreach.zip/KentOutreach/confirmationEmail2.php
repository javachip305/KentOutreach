<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!--Custom CSS -->
    <link rel="stylesheet" href="styles/home.css">
    <title>Kent Outreach</title>
</head>
<body>
<!-- Navigation bar -->
<nav class="navbar navbar-dark navbar-expand-sm" >
    <div class="container">
        <!-- logo -->
        <a href="http://java-chip.greenriverdev.com/KentOutreach/home.html" class="navbar-brand" id="logo"><strong>Kent Outreach</strong></a>
    </div><!-- container -->
</nav>
<br><br><br>

<div class="container" id="main">
    <br>
    <h1><strong>Thank you for your request! We'll be in touch soon!</strong></h1><br>
    <h2>Intake Form Summary</h2><br>

    <?php

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $zipCode = $_POST['zipCode'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];


    $checkedBox = implode(", ", $_POST['checkedBox']);
    $otherInput = $_POST['otherInput'];



    $fromName = $fname." ".$lname;
    $fromEmail = "hmonatt@mail.greenriver.edu";


    // Print Intake Form Summary
    echo "<p><strong>Name:</strong> $fname $lname</p>";
    echo "<p><strong>Zip Code:</strong> $zipCode</p>";
    echo "<p><strong>Phone:</strong> $phone</p>";
    echo "<p><strong>Email:</strong> $email</p>";
    echo "<p><strong>Assistance With:</strong> $checkedBox</p>";
    echo "<p><strong>Other Description:</strong> $otherInput</p><br>";

    // Send Email
    $to = $email;
    $subject = "Kent Outreach Request Form Submitted";
    $message = "Submitted by: $fname $lname\r\n";
    $message .= "Zip Code: $zipCode\r\n";
    $message .= "Phone: $phone\r\n";
    $message .= "Assistance with: $checkedBox\r\n";
    $message .= "Other Description: $otherInput";
    $headers = "Name: $fromName <$fromEmail>";

    echo "<p><a href='confirmationEmail.php' onclick='email()'><strong>Confirm Details</strong></p></a>";

    // Direct link back to homepage
    echo "<p><a href='home.html'><strong>Return to the home page</strong></p></a>";

    function email(){
        global $sxml;
        $child = $to->addChild('to');
        $child = $subject->addChild('subject');
        $child = $message->addChild('message');
        $child = $headers->addChild('headers');

        $success = mail($to, $subject, $message, $headers);

        echo $success ? "<h3>Your request has been submitted.</h3>" :
            "<h3>Sorry...there was a problem.</h3><br>";
    }

    ?>

</div>
</body>
</html>


