<?php
/*
 * Heather Monatt
 * requests.php
 * Display requests for help
 */

// Turn on error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Redirect if form has not been submitted
//if(empty($_POST)){
   // header("location: KentOutreach/form.html");
//}

// Includes
require('includes/dbcreds.php');

?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <!--Custom CSS -->
    <link rel="stylesheet" href="styles/home.css">
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/requests.css">
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css">
    <title>Kent Outreach</title>

</head>

<!-- Navigation bar -->
<nav class="navbar navbar-dark navbar-expand-sm" >
    <div class="container">
        <!-- logo -->
        <a href="http://java-chip.greenriverdev.com/KentOutreach/home.html" class="navbar-brand" id="logo"><strong>Kent Outreach</strong></a>
    </div><!-- container -->
</nav>
<br><br>


<div class="container">
    <br><br>
    <h1><strong>OUTREACH REQUESTS</strong></h1><br>

</div>

<div class="container" id="main">
    <br>
    <h2><strong>Requests</strong></h2>
    <br>
    <table id="requests-table" class="display">
        <thead>
        <tr>
            <td>RequestID</td>
            <td>Name</td>
            <td>Zip
            <td>Phone</td>
            <td>Email</td>
            <td>Needs</td>
            <td>Timestamp</td>
        </tr>
        </thead>
        <tbody>

    <?php
    $sql = "SELECT * FROM requests";
    global $cnxn;
    $result = mysqli_query($cnxn, $sql);

    //var_dump($result);

    foreach($result as $row){
        //var_dump($row);
       //var_dump($row);
        $request_id = $row['request_ID'];
        //$fname = $row['fname'];
        $fullname = $row['firstName'] . " " . $row['lastName'];
        //$lname = $row['lname'];
        $zip = $row['zip'];
        $phone = $row['phone'];
        $email = $row['email'];
        $needs = $row['need'];
        $request_date = date("M d, Y g:i a", strtotime($row['requestDate']));

        echo"<tr>";
        echo"<td>$request_id</td>";
        echo"<td>$fullname</td>";
        echo"<td>$zip</td>";
        echo"<td>$phone</td>";
        echo"<td>$email</td>";
        echo"<td>$needs</td>";
        echo"<td>$request_date</td>";
        echo"</tr>";

    }
    ?>
        </tbody>
    </table>
    <br>
</div>
<br><br>
<div class="container">
    <a href="http://java-chip.greenriverdev.com/KentOutreach/home.html" class="links"><p><strong>Go Back to Home Page</strong></p></a>
</div>
<br><br>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
<script src="scripts/form.js"></script>
<script src="//cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script>
    $('#requests-table').DataTable({
        "order": [[ 0, "desc" ]]
    });
</script>

</body>
</html>



